/* ============================================================
   QUIZ — Pense Antes de Clicar
   Rodada 1: como agir na internet
   Rodada 2: REAL ou FAKE na era da IA (com pegadinhas)
   ============================================================ */

const ROUND1 = [
  {
    text: 'Chega no grupo da família: "URGENTE! Farmácia distribui remédio grátis que cura tudo. Compartilhe antes que tirem do ar!". O que você faz primeiro?',
    options: [
      'Compartilho na hora: se for verdade, pode ajudar alguém.',
      'Procuro a informação no site oficial da farmácia e em agências de checagem antes de qualquer coisa.',
      'Não compartilho, mas também não falo nada e sigo o dia.',
      'Pergunto no próprio grupo se alguém acha que é verdade.'
    ],
    answer: 1,
    why: '<strong>Resposta correta: B.</strong> "Compartilhar no sim, na dúvida" é justamente o combustível do boato — mensagens que mandam repassar rápido e usam urgência ("antes que tirem do ar") existem para desligar seu pensamento crítico. Checar na fonte oficial leva 1 minuto. E o item C também falha: se você já sabe que é suspeito, avisar o grupo com o link da checagem interrompe a corrente. Votação no grupo (D) não é checagem — é enquete.'
  },
  {
    text: 'Verdadeiro ou Falso: se uma imagem tem aparência de foto real, com boa qualidade e detalhes nítidos, então ela não pode ter sido gerada por Inteligência Artificial.',
    options: ['Verdadeiro', 'Falso'],
    answer: 1,
    why: '<strong>Resposta correta: Falso.</strong> Geradores atuais produzem imagens indistinguíveis de fotos à primeira vista. Qualidade alta não é prova de nada — o que vale é a <strong>procedência</strong>: quem publicou primeiro, existe registro do mesmo fato por veículos diferentes, há outras fotos/ângulos do mesmo acontecimento? Busca reversa de imagem continua sendo sua melhor amiga.'
  },
  {
    text: 'Você compartilhou uma notícia e depois descobriu que era falsa. Qual é a atitude mais responsável?',
    options: [
      'Apagar a mensagem em silêncio, porque ninguém viu mesmo.',
      'Deixar como está: quem leu que se vire e cheque.',
      'Apagar e avisar publicamente no mesmo lugar, explicando que era falso e mostrando a checagem.',
      'Postar outra notícia boa para compensar.'
    ],
    answer: 2,
    why: '<strong>Resposta correta: C.</strong> Errar acontece — o problema é deixar a mentira circulando com o seu aval. A correção precisa alcançar as mesmas pessoas que viram o erro, por isso ela vai no mesmo grupo/feed, com o link da checagem. Isso, inclusive, é o que veículos sérios fazem: publicam erratas.'
  }
];

const ROUND2 = [
  {
    headline: 'Foto do Papa Francisco desfilando com uma jaqueta puffer branca de grife viraliza no mundo todo.',
    real: false,
    why: '<strong>FAKE.</strong> A imagem foi gerada por IA (Midjourney) em março de 2023 e enganou milhões de pessoas — inclusive gente acostumada com internet. Foi um dos primeiros casos globais de imagem sintética a virar "notícia". Pistas: os óculos se fundem à pele, a mão que segura o copo está deformada e o crucifixo tem só um lado da corrente.'
  },
  {
    headline: 'Funcionário do setor financeiro de uma multinacional em Hong Kong transferiu cerca de US$ 25 milhões após participar de uma videochamada em que o diretor financeiro e outros colegas eram deepfakes.',
    real: true,
    why: '<strong>REAL — e esse é o mais absurdo da lista.</strong> Caso divulgado pela polícia de Hong Kong no início de 2024: o funcionário desconfiou de um e-mail, pediu uma videoconferência para confirmar... e todos os participantes da chamada eram recriações digitais geradas a partir de vídeos públicos reais. Moral: nem "vi e ouvi a pessoa" é mais prova suficiente. Confirme por um canal alternativo que você mesmo iniciou.'
  },
  {
    headline: 'Imagem de uma grande explosão ao lado do Pentágono, nos EUA, circulou em perfis verificados e chegou a derrubar índices da bolsa por alguns minutos.',
    real: false,
    why: '<strong>FAKE (com efeito real).</strong> A foto da explosão foi gerada por IA em maio de 2023 e nunca houve explosão alguma — o Corpo de Bombeiros local desmentiu. Mas o susto durou o suficiente para mexer no mercado financeiro. Aqui mora a pegadinha: <em>o conteúdo era falso, a consequência foi real</em>. Detalhe denunciador: as colunas do prédio derretiam umas nas outras e a grade da cerca desaparecia no meio do caminho.'
  },
  {
    headline: 'Um evento infantil inspirado na Fábrica de Chocolate foi divulgado com imagens mágicas feitas por IA, cobrou ingresso, e as famílias encontraram um galpão quase vazio com poucas balas — a polícia precisou ser chamada.',
    real: true,
    why: '<strong>REAL.</strong> A "Willy\'s Chocolate Experience", em Glasgow (Escócia), em fevereiro de 2024, usou cartazes e um site inteiros gerados por IA — com textos sem sentido no meio das imagens. O que existia de verdade era um galpão com poucos adereços; pais indignados chamaram a polícia e o evento foi encerrado no mesmo dia. Lição: propaganda feita por IA pode prometer um mundo que não existe fisicamente.'
  },
  {
    headline: 'Foto comovente de uma menininha chorando, abraçada a um filhote, dentro de um barco durante uma enchente causada por furacão, viraliza como registro da tragédia.',
    real: false,
    why: '<strong>FAKE — e a mais cruel do tipo.</strong> A tragédia existiu, mas a foto não: é imagem gerada por IA, do tipo que se espalha porque mexe com a emoção antes de mexer com a razão (caso do furacão Helene, EUA, 2024). Repare em desastres recentes: sempre aparecem imagens "perfeitas demais" de crianças e animais. Pistas comuns: dedos a mais, a mesma menina em versões diferentes da imagem, olhos vidrados e chuva que não molha ninguém.'
  },
  {
    headline: 'Pesquisadores desligaram às pressas uma inteligência artificial depois que ela criou sozinha uma língua secreta para conversar com outra IA sem que os humanos entendessem.',
    real: false,
    why: '<strong>FAKE por distorção — o tipo mais difícil de pegar.</strong> Existiu um experimento real (Facebook, 2017) em que dois programas de negociação passaram a repetir frases em inglês malformado porque não foram instruídos a manter a gramática. Os pesquisadores encerraram o teste por ele não servir mais ao objetivo — não por medo. O boato pegou um fato verdadeiro e trocou a explicação por uma história de ficção científica. Sempre que a manchete parecer roteiro de filme, vá atrás da pesquisa original.'
  }
];

const state = { answered: {}, score: 0 };
const TOTAL = ROUND1.length + ROUND2.length;

function letter(i) { return String.fromCharCode(65 + i); }

function buildQuestion(id, number, headerHTML, options, isCorrect, why) {
  const q = document.createElement('article');
  q.className = 'q';

  const head = document.createElement('div');
  head.className = 'q__head';
  head.innerHTML = `<span class="q__n">${number}</span><div>${headerHTML}</div>`;
  q.appendChild(head);

  const opts = document.createElement('div');
  opts.className = 'opts';

  const feedback = document.createElement('div');
  feedback.className = 'feedback';
  feedback.hidden = true;

  options.forEach((label, i) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'opt';
    b.innerHTML = `<span class="opt__key">${letter(i)}</span><span>${label}</span>`;
    b.addEventListener('click', () => {
      if (state.answered[id]) return;
      state.answered[id] = true;

      const correct = isCorrect(i);
      if (correct) state.score++;

      [...opts.children].forEach((el, j) => {
        el.disabled = true;
        if (isCorrect(j)) el.classList.add('is-correct');
      });
      if (!correct) b.classList.add('is-wrong');

      feedback.dataset.state = correct ? 'ok' : 'no';
      feedback.innerHTML =
        `<span class="verdict">${correct ? 'Você acertou' : 'Caiu na pegadinha'}</span><br />${why}`;
      feedback.hidden = false;
      updateProgress();
    });
    opts.appendChild(b);
  });

  q.appendChild(opts);
  q.appendChild(feedback);
  return q;
}

function renderQuiz() {
  const r1 = document.getElementById('round1');
  const r2 = document.getElementById('round2');
  r1.innerHTML = '';
  r2.innerHTML = '';

  ROUND1.forEach((item, idx) => {
    r1.appendChild(
      buildQuestion(`r1-${idx}`, `PERGUNTA ${idx + 1}`, `<p class="q__text" style="margin:0">${item.text}</p>`,
        item.options, (i) => i === item.answer, item.why)
    );
  });

  ROUND2.forEach((item, idx) => {
    const header =
      `<p class="q__text" style="margin:0">Esta manchete descreve um fato que realmente aconteceu?
       <span class="q__quote">“${item.headline}”</span></p>`;
    r2.appendChild(
      buildQuestion(`r2-${idx}`, `MANCHETE ${idx + 1}`, header,
        ['É REAL — aconteceu de verdade', 'É FAKE — conteúdo fabricado ou distorcido'],
        (i) => (i === 0) === item.real, item.why)
    );
  });

  updateProgress();
}

function updateProgress() {
  const answered = Object.keys(state.answered).length;
  document.getElementById('quizBar').style.width = `${(answered / TOTAL) * 100}%`;
  document.getElementById('quizScore').textContent = `Acertos: ${state.score} de ${TOTAL}`;

  const box = document.getElementById('quizResult');
  if (answered < TOTAL) { box.hidden = true; return; }

  let title, msg;
  if (state.score <= 3) {
    title = 'Zona de perigo 🚨';
    msg = 'Sem julgamento: essas manchetes foram escolhidas para enganar mesmo. Volte na Seção 3, aplique os 5 passos e refaça — o objetivo aqui é sair com o hábito de desconfiar, não com a pontuação.';
  } else if (state.score <= 6) {
    title = 'Você tem faro, mas a IA te pegou';
    msg = 'Bom desempenho na teoria; o difícil é na hora do feed. Fixe a regra de ouro: qualidade de imagem não prova nada, procedência prova. Antes de repassar, procure o mesmo fato em outro veículo grande.';
  } else if (state.score < TOTAL) {
    title = 'Detetive digital avançado 🔍';
    msg = 'Você errou pouco e pelos motivos certos. Agora vem a parte que importa: ensine esses 5 passos para alguém da sua família que costuma repassar tudo no grupo.';
  } else {
    title = 'Gabaritou. Impressionante. 🏆';
    msg = 'Nem a chamada de vídeo com deepfake te pegou. Seu próximo nível é virar multiplicador: apresente este guia na sua turma e mande o QR Code para a família.';
  }
  box.innerHTML = `<h3>${title}</h3><p style="margin:0">Você fez <strong>${state.score} de ${TOTAL}</strong>. ${msg}</p>`;
  box.hidden = false;
  box.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

document.getElementById('quizReset').addEventListener('click', () => {
  state.answered = {};
  state.score = 0;
  renderQuiz();
  document.getElementById('quiz').scrollIntoView({ behavior: 'smooth' });
});

renderQuiz();

/* QR Code do endereço atual (com fallback para colar manualmente) */
(function qr() {
  const img = document.getElementById('qrImage');
  const fallback = document.getElementById('qrFallback');
  const url = location.href.startsWith('http') ? location.href : 'https://exemplo.com/seu-site';
  img.onload = () => { fallback.hidden = true; };
  img.onerror = () => { img.remove(); };
  img.src = 'https://api.qrserver.com/v1/create-qr-code/?size=180x180&margin=0&data=' + encodeURIComponent(url);
})();
